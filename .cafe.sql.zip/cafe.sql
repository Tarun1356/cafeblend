-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2021 at 03:11 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cafe`
--

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `billid` int(11) NOT NULL,
  `cname` varchar(20) NOT NULL,
  `tableno` int(11) NOT NULL,
  `pname` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`billid`, `cname`, `tableno`, `pname`, `quantity`, `rate`, `total`) VALUES
(1, 'ramesh singh', 2, 'manchurian', 2, 120, 140),
(2, 'rajendra mudgal', 3, 'sho-sha_specialpizza', 2, 140, 280),
(3, 'taruna', 1, 'cheesesandwich', 1, 65, 65),
(4, 'savan', 1, 'chocochip', 1, 30, 30),
(5, 'hritika', 3, 'chillipaneer', 1, 30, 30),
(6, 'priya', 4, 'chocochip', 2, 30, 60),
(7, 'ramansh', 8, 'hakanoodles', 3, 100, 300),
(8, 'sana', 6, 'chocholatemousse', 1, 100, 100),
(9, 'shiv', 9, 'sho-sha_specialpizza', 1, 140, 140),
(10, 'tarun', 10, 'maggie', 1, 40, 40),
(11, 'neha', 6, 'chocochip', 2, 30, 60);

-- --------------------------------------------------------

--
-- Table structure for table `mainmenu`
--

CREATE TABLE `mainmenu` (
  `mid` int(11) NOT NULL,
  `products` varchar(50) NOT NULL,
  `courses` varchar(20) NOT NULL,
  `price` int(11) NOT NULL,
  `p_image` varchar(30) NOT NULL DEFAULT 'coldcoffee with icecream.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mainmenu`
--

INSERT INTO `mainmenu` (`mid`, `products`, `courses`, `price`, `p_image`) VALUES
(1, 'manchurian', 'Starter', 120, 'coldcoffee with icecream.jpg'),
(2, 'chillipaneer', 'Starter', 150, 'coldcoffee with icecream.jpg'),
(3, 'chocochip', 'Dessert', 50, 'coldcoffee with icecream.jpg'),
(6, 'maggie', 'Starter', 50, 'coldcoffee with icecream.jpg'),
(7, 'cheesesandwich', 'Starter', 65, 'coldcoffee with icecream.jpg'),
(8, 'cheeseloadedpizza', 'Starter', 120, 'coldcoffee with icecream.jpg'),
(9, 'sho-sha_specialpizza', 'Starter', 140, 'coldcoffee with icecream.jpg'),
(10, 'blackcurrent', 'Dessert', 30, 'coldcoffee with icecream.jpg'),
(11, 'chocholatemousse', 'Dessert', 100, 'coldcoffee with icecream.jpg'),
(12, 'Applepie', 'Dessert', 70, 'coldcoffee with icecream.jpg'),
(13, 'Gulabjamun', 'Dessert', 30, 'coldcoffee with icecream.jpg'),
(15, 'Cookiedough ', 'Dessert', 45, 'coldcoffee with icecream.jpg'),
(16, 'vanilla', 'Dessert', 40, 'vanilla.jpg'),
(17, 'mojitomocktails', 'Drinks', 80, 'coldcoffee with icecream.jpg'),
(18, 'coldcoffee', 'Drinks', 100, 'coldcoffee with icecream.jpg'),
(19, 'chinesebhel', 'Starter', 110, 'coldcoffee with icecream.jpg'),
(20, 'pavbhaji', 'Main course', 130, 'coldcoffee with icecream.jpg'),
(21, 'vegdosa', 'Main course', 120, 'coldcoffee with icecream.jpg'),
(24, 'vegmomos', 'Starter', 65, 'coldcoffee with icecream.jpg'),
(25, 'cholebhature', 'Main course', 150, 'coldcoffee with icecream.jpg'),
(26, 'palakpaneer', 'Main course', 140, 'coldcoffee with icecream.jpg'),
(28, 'coldcoffeewithicecream', 'Dessert', 150, 'coldcoffee with icecream.jpg'),
(29, 'Kaaju_paneer', 'Main course', 140, 'kaajupaneer.png');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `odid` int(11) NOT NULL,
  `oid` int(11) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `oid` int(11) NOT NULL,
  `tblno` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `grandtotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_temp`
--

CREATE TABLE `order_temp` (
  `pname` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `tableno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_temp`
--

INSERT INTO `order_temp` (`pname`, `qty`, `price`, `tableno`) VALUES
('Applepie', 1, 2, 60),
('blackcurrent', 1, 30, 2),
('chillipaneer', 1, 140, 2);

-- --------------------------------------------------------

--
-- Table structure for table `porders`
--

CREATE TABLE `porders` (
  `oid` int(11) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `tableno` int(11) NOT NULL,
  `billstatus` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `porders`
--

INSERT INTO `porders` (`oid`, `pname`, `quantity`, `tableno`, `billstatus`) VALUES
(4, 'manchurian', 2, 2, 1),
(5, 'chillipaneer', 1, 3, 1),
(6, 'chocochip', 2, 4, 1),
(7, 'hakanoodles', 3, 8, 1),
(8, 'chocholatemousse', 1, 6, 1),
(9, 'sho-sha_specialpizza', 1, 9, 1),
(10, 'maggie', 1, 10, 1),
(11, 'hakanoodles', 1, 5, 0),
(12, 'sho-sha_specialpizza', 2, 3, 1),
(13, 'cheesesandwich', 1, 1, 1),
(14, 'chocochip', 1, 1, 1),
(15, 'blackcurrent', 2, 6, 0),
(16, 'chocochip', 2, 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `username`, `password`) VALUES
(1, 'manager', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`billid`);

--
-- Indexes for table `mainmenu`
--
ALTER TABLE `mainmenu`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`odid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `porders`
--
ALTER TABLE `porders`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `billid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `mainmenu`
--
ALTER TABLE `mainmenu`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `odid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `porders`
--
ALTER TABLE `porders`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
